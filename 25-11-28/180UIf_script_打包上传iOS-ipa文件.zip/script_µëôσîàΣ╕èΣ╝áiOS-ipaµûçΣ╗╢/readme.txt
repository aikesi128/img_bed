
这是一个标准脚本打包程序, 使用方法:
1. 将本模块复制到你对应的项目文件夹中
2. 修改两个plist文件中的teamID为你自己的开发者账号的teamID, plist文件直接用这两个就行, 不用自己打包再去导出然后去找plist模版.
3. spider.py中的fixme标记的地方, 必须要修改为你自己对应的参数
4. 双击package.command开始.


参考文档:  https://aikesi128.github.io/a26/docs/ios/%E8%87%AA%E5%8A%A8%E5%8C%96%E6%89%93%E5%8C%85.html